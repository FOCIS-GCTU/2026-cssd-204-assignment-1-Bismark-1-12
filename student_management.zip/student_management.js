/*
File: student_management.js
Description:This script generates a student report and manages student information
Assignment Number: 11
Name: Bismark Anakwa Kwadwo 
SID:  2425403907
 Email: 2425403907@live.gctu.edu.gh
 Grader: Ahmad


On my honor, I have neither given nor received
unauthorized aid on this assignment.
*/

"use strict";

/*
==================================================
Student Class
==================================================
*/

class Student {
  constructor(studentId, studentName, course, score) {
    this.studentID = studentId;      
    this.name = studentName;          
    this.course = course;            
    this.score = Number(score);      
  }

    /*
    Returns the student's letter grade.

    A : 80 - 100
    B : 70 - 79
    C : 60 - 69
    D : 50 - 59
    F : Below 50
    */
    getGrade() {
    if (this.score >= 80) {
      return "A";
    } else if (this.score >= 70) {
      return "B";
    } else if (this.score >= 60) {
      return "C";
    } else if (this.score >= 50) {
      return "D";
    } else {
      return "F";
    }
  }

    /*
    Returns true if the student passed.
    Otherwise returns false.
    */
   hasPassed() {
    if (this.score >= 50) {
      return true;
    } else {
      return false;
    }
  }


    /*
    Returns true if the student
    scored 90 or above.
    */
    isExcellent() {
    if (this.score >= 90) {
      return true;
    } else {
      return false;
    }
  }

    /*
    Returns the class average.
    */
   static calculateAverage(studentList) {
    let totalScore = 0;

    for (const student of studentList) {
      totalScore += student.score;
    }

    let average = totalScore / studentList.length;
    return Number(average.toFixed(2));
  }
}



/*
==================================================
Student Objects
==================================================
*/



const students = [
  new Student("CS001", "Ama", "CSSD204", 78),
  new Student("CS002", "Kwame", "CSSD204", 92),
  new Student("CS003", "Akosua", "CSSD204", 67),
  new Student("CS004", "Yaw", "CSSD204", 55),
  new Student("CS005", "Kojo", "CSSD204", 84),
  new Student("CS006", "Abena", "CSSD204", 49),
  new Student("CS007", "Kofi", "CSSD204", 73),
  new Student("CS008", "Efua", "CSSD204", 95)
];

/*
==================================================
Programmer-defined Functions

Create AT LEAST FOUR additional functions.

Suggested ideas (examples only):

displayStudents()

displayPassedStudents()

displayFailedStudents()

displayExcellentStudents()

displayHighestScore()

displayLowestScore()

displayAverage()

generateReport()

You may use different function names.
==================================================
*/
function getHighestScore(studentList) {
  let highest = studentList[0].score;
  for (const student of studentList) {
    if (student.score > highest) {
      highest = student.score;
    }
  }
  return highest;
}

function getLowestScore(studentList) {
  let lowest = studentList[0].score;
  for (const student of studentList) {
    if (student.score < lowest) {
      lowest = student.score;
    }
  }
  return lowest;
}

const getPassedStudents = (studentList) => {
  return studentList.filter((student) => student.hasPassed());
};

function getFailedStudents(studentList) {
  const failedStudents = [];
  for (const student of studentList) {
    if (!student.hasPassed()) {
      failedStudents.push(student);
    }
  }
  return failedStudents;
}

function getExcellentStudents(studentList) {
  const excellentStudents = [];
  for (const student of studentList) {
    if (student.isExcellent()) {
      excellentStudents.push(student);
    }
  }
  return excellentStudents;
}














/*
==================================================
Main Program
==================================================
*/

// TODO
// Call your functions here to generate
// the Student Management Report.
function printStudentReport(studentList) {
  console.log("==============================");
  console.log("STUDENT MANAGEMENT REPORT");
  console.log("==============================");

  console.log(`Total Students : ${studentList.length}`);
  console.log(`Highest Score  : ${getHighestScore(studentList)}`);
  console.log(`Lowest Score   : ${getLowestScore(studentList)}`);

  const averageScore = Student.calculateAverage(studentList);
  console.log(`Average Score  : ${averageScore}`);

  console.log("\nStudents Passed\n");
  const passedStudents = getPassedStudents(studentList);
  for (const student of passedStudents) {
    console.log(`${student.studentID} ${student.name} (${student.getGrade()})`);
  }

  console.log("\nStudents Failed\n");
  const failedStudents = getFailedStudents(studentList);
  for (const student of failedStudents) {
    console.log(`${student.studentID} ${student.name} (${student.getGrade()})`);
  }

  console.log("\nExcellent Students\n");
  const excellentStudents = getExcellentStudents(studentList);
  for (const student of excellentStudents) {
    console.log(`${student.studentID} ${student.name}`);
  }
}


// Run the report
printStudentReport(students);














/*
==================================================
Do NOT modify anything below this line.
Required for GitHub Classroom autograding.
==================================================
*/

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    Student,
    students,
    getHighestScore,
    getLowestScore,
    getPassedStudents,
    getFailedStudents,
    getExcellentStudents,
    printStudentReport
  };        
}